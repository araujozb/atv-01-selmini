import java.util.ArrayList;
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        ArrayList<Integer> array = new ArrayList<Integer>();
        System.out.println("Digite o tamanho do array: ");
        int n = sc.nextInt();
        System.out.println("Digite os valores do array: ");
        for (int i = 0; i < n; i++) {
            array.add(sc.nextInt());
        }
        if (soma(array)) {
            System.out.println("Existe um elemento que é a soma de dois anteriores.");
        } else {
            System.out.println("Nenhum elemento é a soma de dois anteriores.");
        }
        sc.close();
    }

    public static boolean soma(ArrayList<Integer> array) {
        for (int i = 2; i < array.size(); i++) {
            for (int j = 0; j < i - 1; j++) {
                for (int k = j + 1; k < i; k++) {
                    if (array.get(i) == array.get(j) + array.get(k)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
