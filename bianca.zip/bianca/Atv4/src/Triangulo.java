public class Triangulo {
    private double a, b, c;

    public Triangulo(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public double calcularArea() {
        double p = (a + b + c) / 2;
        return Math.sqrt(p * (p - a) * (p - b) * (p - c));
    }

    public double calcularPerimetro() {
        return a + b + c;
    }

    public double[] calcularCentroide() {
        double x = (b + a * (b * b + a * a - c * c) / (2 * a * b)) / 3;
        double y = (a * Math.sqrt(1 - Math.pow((b * b + a * a - c * c) / (2 * a * b), 2))) / 3;
        return new double[]{x, y};
    }
}