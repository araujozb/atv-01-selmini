import java.util.ArrayList;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Triangulo> triangulos = new ArrayList<>();

        System.out.println("Digite o número de triângulos: ");
        int n = sc.nextInt();

        for (int i = 0; i < n; i++) {
            System.out.println("Digite os lados do triângulo " + (i + 1) + ": ");
            double a = sc.nextDouble();
            double b = sc.nextDouble();
            double c = sc.nextDouble();
            triangulos.add(new Triangulo(a, b, c));
        }

        for (Triangulo triangulo : triangulos) {
            System.out.println("Área: " + triangulo.calcularArea());
            System.out.println("Perímetro: " + triangulo.calcularPerimetro());
            double[] centroide = triangulo.calcularCentroide();
            System.out.println("Centróide: (" + centroide[0] + ", " + centroide[1] + ")");
        }

        sc.close();
    }
}