
import java.util.ArrayList;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Integer> array = new ArrayList<Integer>();
        System.out.println("Digite o tamanho do array: ");
        int n = sc.nextInt();
        System.out.println("Digite os valores do array: ");
        for (int i = 0; i < n; i++) {
            array.add(sc.nextInt());
        }
        System.out.println("Número repetido: " + pNumero(array));
        sc.close();
    }

    public static int pNumero(ArrayList<Integer> array) {
        for (int i = 0; i < array.size(); i++) {
            for (int j = i + 1; j < array.size(); j++) {
            if (array.get(i).equals(array.get(j))) {
                return array.get(i);
            }
            }
        }
        return -1;
    }
}
