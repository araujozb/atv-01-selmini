import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o tamanho do array: ");
        int n = sc.nextInt();
        int[] array = new int[n];
        System.out.println("Digite os valores do array: ");
        for (int i = 0; i < n; i++) {
            array[i] = sc.nextInt();
        }
        System.out.println("Digite o valor de k: ");
        int k = sc.nextInt();
        
        reorganizarArray(array, k);
        
        System.out.println("Array reorganizado: ");
        for (int num : array) {
            System.out.print(num + " ");
        }
        sc.close();
    }

    public static void reorganizarArray(int[] array, int k) {
        int left = 0;
        int right = array.length - 1;
        
        while (left <= right) {
            if (array[left] <= k) {
                left++;
            } else if (array[right] > k) {
                right--;
            } else {
                int temp = array[left];
                array[left] = array[right];
                array[right] = temp;
                left++;
                right--;
            }
        }
    }
}

